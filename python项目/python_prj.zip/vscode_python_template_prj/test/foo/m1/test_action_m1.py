import unittest
import src.foo.m1.action_m1 as action_m1


class TestActionM1(unittest.TestCase):

    def test_action_m1(self):
        self.assertEqual('m1', action_m1.get_m1_value())