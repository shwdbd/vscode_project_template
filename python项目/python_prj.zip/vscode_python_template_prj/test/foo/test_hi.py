# import foo.hi
import src.foo.m1.action_m1 as a1
import unittest
import sys
import src.foo.hi


class TestHi(unittest.TestCase):

    def test_hi(self):
        print('test_hi')
        # for path in sys.path:
        #     print(path)
        
        print(a1.get_m1_value())
        
        self.assertTrue(True)
