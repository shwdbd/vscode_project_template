# python新建虚拟手册

本文是创建新项目python虚拟环境的操作指南。

读者可按照步骤一步步构建可用vscode项目可用的python虚拟环境。

创建python有3个步骤：

1. 新建python venv
2. 安装第三方库
3. 添加.pth文件

本文内容在win10，anaconda3.6环境下测试通过。下面是具体步骤的说明：

[TOC]

## 第1步，新建虚拟环境

### 操作步骤

在windows操作系统中键入Ctrl+R，输入cmd进行命令行：

然后输入：

```command
python -m venv 新环境名 --system-site-packages
```

然后就在当前目录下生成名为"新环境名"的目录，比如 my_project

### 验证方法

在命令行中输入：（假设新建的环境名为 my_project）

```command
c:> cd my_project\scripts
c:\my_project\scripts>activate
```

然后显示：

```command
(my_project) c:\my_project\Scripts>activate
```

如看到有(my_project)前缀，就说明进入了新建的虚拟环境，表示创建成功。

## 第2步，安装第三方库

找到requirements.txt文件，通常在项目根目录或\venv目录下。

### 操作步骤

1. 从命令行进入虚拟环境
2. [可选] 升级pip（命令：python -m pip install --upgrade pip）
3. 在命令行中输入：pip install -r requirements.txt，系统自动安装缺失的类库；

### 验证方法

写一个新的代码，尝试import tushare等的anaconda非默认的第三方类库，如不报错则表示成功

## 第3步，添加.pth文件

**.pth文件**是虚拟环境中sys.path的配置文件，在这个文件中的路径将自动加到sys.path全局变量中

### 操作步骤

找到虚拟目录下的 \Lib\site-packages\子目录

找到（或新建） .pth 文件，其内容为（分别指向项目源代码目录和单元测试源代码目录）：

```text
C:\\myproject\\src
C:\\myproject\\test
```

### 验证方法

在vscode项目中新建一个moudle（假设为foo.m1），然后写另一个module（假设为foo.m2），在m2中import m1，运行不报错则表示生效

------

王道霸道，新的捕蛇者（Python Hunter）

Email：shwangjj@163.com