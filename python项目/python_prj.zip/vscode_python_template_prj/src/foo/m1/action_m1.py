def get_m1_value():
    return 'm1'
