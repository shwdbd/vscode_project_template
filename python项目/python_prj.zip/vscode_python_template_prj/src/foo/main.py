# import foo.hi
import foo.m1.action_m1 as action_m1
import foo.m2.action_m2 as action_m2

print(action_m1.get_m1_value())
print(action_m2.get_m2_value())
