def get_m2_value():
    return 'm2'
